//leonardo acuña
/*Se desea construir un programa en java que permita calcular el costo total de un viaje que tiene una duración en días.
Para ello, se requiere los siguientes datos: Número de días del viaje, Total de kilómetros conducidos por día, costo por
litro de gasolina, promedio de kilometro por litro de gasolina, pago por estacionamiento por día, pago de peajes por día.
Imprima en consola el resultado.*/
package punto4;
public class codigo_punto4 {
    public static void main (String[] args){
        int num_dias_viaje,km_dia,peaje_dias,costolitrogas,litro_gasolina,estacionamiento_dia,peaje_dia,km_conducidos,litros_dia,pago_esta;
        int costo_total_viaje;
        double prom_km_por_litro;
        num_dias_viaje = 7;
        km_dia = 100;
        litro_gasolina = 4000;
        litros_dia = 5;
        peaje_dia=5000;
        estacionamiento_dia = 7000;
        //1litro=3.7km
        prom_km_por_litro=km_dia/litros_dia;  //pormedio kim por litro de gasolina
        pago_esta = estacionamiento_dia*num_dias_viaje;//pago por estacionamientos por dias de viaje
        costolitrogas=litro_gasolina*litros_dia*num_dias_viaje;//costo gasolina por dias de viaje
        peaje_dias = peaje_dia*num_dias_viaje;//pago de peajes por dias de viajes
        km_conducidos = (km_dia*num_dias_viaje);//total km conducidos por dias
        costo_total_viaje=pago_esta+costolitrogas+peaje_dias;
        System.out.println("el costo total del viaje es de: "+costo_total_viaje);
        System.out.println("el promedio de kilometro por litro de gasooina es; "+prom_km_por_litro);
        System.out.println("cantidad de kilometros conducidos por los dia de viaje: "+km_conducidos);
}   
}
