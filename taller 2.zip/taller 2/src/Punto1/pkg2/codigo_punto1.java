//leonardo acuña
/*Escriba un programa en java que defina una variable “x” de tipo entero, con un valor inicial (el que usted decida), y
muestre el resultado de las siguientes instrucciones:*/
package Punto1.pkg2;
public class codigo_punto1 {
    public static void main(String[] args) {
        int x=50;
        double conver;
        conver=x;
        System.out.printf("x = %d\n", x );
        System.out.printf("El valor de %d + %d es %d\n", x, x, ( x + x ) );
        System.out.printf("El valor de %d / 2 =%.2f \n", x, (conver /2) );
        System.out.printf("El valor de %d mod 3 = %d\n", x, x%3 );
    }
}
