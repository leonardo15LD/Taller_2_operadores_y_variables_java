//leonardo acuña
/*Escriba una aplicación que defina tres variables numéricas, con sus valores iniciales, y muestre la suma, promedio,
producto, cociente y modulo. Los resultados se deben imprimir en formato decimal con dos cifras significativas*/
package punto2;
public class codigo_punto2 {
    public static void main(String[] args){
        double num1 = 6;
        double num2 = 14;
        double num3 = 32;
        double suma = num1 + num2 + num3;
        double multiplicacion = num1*num2*num3;
        double promedio = suma/3;
        double cociente = (num1/num2/num3);
        double modulo = (num1%num2%num3);
        System.out.printf("la suma de los 3 numeros es :%.2f %n ",suma);
        System.out.printf("el producto de los 3 numeros es:%.2f %n ", multiplicacion );
        System.out.printf("el promedio de los 3 numeros es:%.2f %n ", promedio );
        System.out.printf("el cociente de los 3 numeros es:%.2f %n ", cociente );
        System.out.printf("el modulo de los 3 numeros es:%.2f %n ", modulo );
    }
}
