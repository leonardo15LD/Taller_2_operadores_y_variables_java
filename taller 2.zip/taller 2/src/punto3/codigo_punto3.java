//leonardo acuña
/*El precio de venta de los artículos de una tienda se calcula a partir de su valor de costo fijo, el porcentaje de iva y su
porcentaje de utilidad. Cree una aplicación en Java, en la que defina e inicialice dichos valores para un artículo, y
calcule y muestre su precio de venta.*/
package punto3;
public class codigo_punto3 {
    public static void main(String[] args){
        int costo_fijo,iva,utilidad,precio_venta,masiva,masutil,sumaventa;
        costo_fijo=70000;
        iva=19;
        utilidad=25;
        masiva=(costo_fijo*19/100);
        masutil=(costo_fijo*25/100);
        sumaventa= masiva + masutil;
        precio_venta = sumaventa+ costo_fijo;
        System.out.println(" el ARTICULO tiene un precio de:"+ costo_fijo+"\n el porcentaje del iva es del: " + iva +"%");
        System.out.println(" el porcentanje de utilidad es: " + utilidad+"\n el PRECIO DE VENTA es: " + precio_venta); 
    }
}
