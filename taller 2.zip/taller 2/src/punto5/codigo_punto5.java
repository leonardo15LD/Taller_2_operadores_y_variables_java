/*En la Tabla 1 se muestran el número de calorías que contienen las principales frutas. ¿Si Juan cena una ensalada de
frutas que contiene 2 manzanas, 3 peras, 1 naranja y 1 melón, cuantas calorías ha consumido? Cree una aplicación en
java que le permita realizar el cálculo, para ello defina e inicialice las variables que considere*/
package punto5;
/**
 *
 * @author LEONARDO ACUÑA
 */
public class codigo_punto5 {
    public static void main (String[]args){
        int manzana,piña,pera,naranja,fresas,melon,total_calorias;
        manzana= 52;
        piña=55;
        pera=55;
        naranja=45;
        fresas=32;
        melon=54;
        total_calorias=(2*manzana+3*pera+1*naranja+1*melon);
        System.out.println("la cantidad de calorias que juan consumio son: "+total_calorias+"kcal");
    }
}
